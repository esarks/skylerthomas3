<?php
/**
 * Plugin Name: Fix Post Navigation Arrows (Menu Order)
 * Description: Swaps post navigation to use menu_order (APTO) instead of date, with left arrow = previous, right arrow = next.
 * Version: 2.0
 * Author: Claude
 */

// Override WordPress navigation to use menu_order
add_filter('get_previous_post_where', 'fpn_prev_post_where');
add_filter('get_previous_post_sort', 'fpn_prev_post_sort');
add_filter('get_next_post_where', 'fpn_next_post_where');
add_filter('get_next_post_sort', 'fpn_next_post_sort');

function fpn_prev_post_where($where) {
    global $post, $wpdb;

    if (!is_singular('post')) {
        return $where;
    }

    $current_menu_order = $post->menu_order;

    // Previous = lower menu_order number
    return $wpdb->prepare(
        "WHERE p.menu_order < %d AND p.post_type = %s AND p.post_status = 'publish'",
        $current_menu_order,
        $post->post_type
    );
}

function fpn_prev_post_sort($sort) {
    if (!is_singular('post')) {
        return $sort;
    }

    // Get the highest menu_order that's still less than current
    return 'ORDER BY p.menu_order DESC LIMIT 1';
}

function fpn_next_post_where($where) {
    global $post, $wpdb;

    if (!is_singular('post')) {
        return $where;
    }

    $current_menu_order = $post->menu_order;

    // Next = higher menu_order number
    return $wpdb->prepare(
        "WHERE p.menu_order > %d AND p.post_type = %s AND p.post_status = 'publish'",
        $current_menu_order,
        $post->post_type
    );
}

function fpn_next_post_sort($sort) {
    if (!is_singular('post')) {
        return $sort;
    }

    // Get the lowest menu_order that's still greater than current
    return 'ORDER BY p.menu_order ASC LIMIT 1';
}

// Now swap the output so left arrow = previous (lower menu_order), right arrow = next (higher menu_order)
add_filter('get_the_post_navigation', 'fpn_swap_navigation_output');
function fpn_swap_navigation_output($navigation) {
    if (!is_singular('post')) {
        return $navigation;
    }

    // Get next and previous posts (now based on menu_order)
    $prev_post = get_previous_post();
    $next_post = get_next_post();

    if (!$prev_post && !$next_post) {
        return '';
    }

    $navigation = '<nav class="navigation post-navigation" role="navigation">';
    $navigation .= '<h2 class="screen-reader-text">Post navigation</h2>';
    $navigation .= '<div class="nav-links">';

    // SWAPPED: Next post (higher menu_order) on the RIGHT with right arrow
    if ($next_post) {
        $navigation .= '<div class="nav-next">';
        $navigation .= '<a href="' . get_permalink($next_post) . '" rel="next">';
        $navigation .= '<span class="screen-reader-text">Next post:</span> ';
        $navigation .= '<span class="post-title">' . get_the_title($next_post) . '</span>';
        $navigation .= ' <span class="meta-nav" aria-hidden="true">→</span>';
        $navigation .= '</a>';
        $navigation .= '</div>';
    }

    // SWAPPED: Previous post (lower menu_order) on the LEFT with left arrow
    if ($prev_post) {
        $navigation .= '<div class="nav-previous">';
        $navigation .= '<a href="' . get_permalink($prev_post) . '" rel="prev">';
        $navigation .= '<span class="meta-nav" aria-hidden="true">←</span> ';
        $navigation .= '<span class="screen-reader-text">Previous post:</span> ';
        $navigation .= '<span class="post-title">' . get_the_title($prev_post) . '</span>';
        $navigation .= '</a>';
        $navigation .= '</div>';
    }

    $navigation .= '</div>';
    $navigation .= '</nav>';

    return $navigation;
}
